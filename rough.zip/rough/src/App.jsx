import react from "react";
import {useState,createContext,useContext} from "react";
import {useEffect,useRef} from "react";
import ReactDOM from 'react-dom/client';
const UserContext=createContext();

function Comp1() {
  const[ipValue,setIpValue]=useState("");
  const count=useRef(0);
  useEffect(()=>
  {
  count.current=count.current+1
  });
  return (
    <>
    <input type="textbox" value={ipValue} onChange={(e)=>setIpValue(e.target.value)}/>
    <h3>count is increased to {count.current} </h3>
    </>
  );
}
  function App()
  {
    return (
      <div style={
        {
          backgroundImage:`url("https://img.freepik.com/free-vector/hand-painted-watercolor-pastel-sky-background_23-2148902771.jpg")`,
          backgroundSize:"cover",
          backgroundRepeat:"no-repeat",
          height:"550px",
          width:"1000%"
        }
      }>
       <h1> Hello World!!</h1>

      </div>
    );
  }

export default App
