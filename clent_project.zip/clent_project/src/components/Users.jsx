import axios from "axios";
import {useState} from "react";
import {Link} from "react-router-dom"
function Users()
{
    const[user,Setuser]=useState([
        {
            name:"sujitha",
            age:"20",
            clg:"vrsec"
        }
    ]);
    return (
        <div className="parent">
            <Link to="/create" className="btn btn-success"> create</Link>
           <div className="child">
            <table>
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Age</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {
                    user.map((user)=>{
                        return <tr>
                            <td>{user.name}</td>
                            <td>{user.age}</td>
                            <td>{user.clg}</td>
                            <td>
                                <Link to={'/update/${user._id}'}>update</Link>
                                <button>Delete</button>
                            </td>
                        </tr>
                    }
                    )
                    }
                </tbody>
            </table>
           </div>

        </div>
    )
}
export default Users