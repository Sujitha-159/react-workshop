import {BrowserRouter,Routes,Route, Router} from "react-router-dom"
import Users from './components/Users'
import CreateUser from './components/CreateUsers';
import UpdateUser from './components/UpdateUsers'

function App() {


  return (
    <div>
      <BrowserRouter>
        <Routes>
            <Route path='/' element={<Users/>}></Route>
            <Route path='/create' element={<CreateUser/>}></Route>
            <Route path='/update/:id' element={<UpdateUser/>}></Route>
        </Routes>
      </BrowserRouter>
    </div>
  )
}

export default App